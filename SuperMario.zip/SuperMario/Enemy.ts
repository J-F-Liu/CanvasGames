﻿class Enemy extends AnimatedSprite {
}